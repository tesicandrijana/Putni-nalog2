create
    definer = student2337@`%` procedure ukupan_br_pn_po_vozacu(IN datum1 date, IN datum2 date)
begin
	SELECT vo.vozno_osoblje_id,CONCAT(rv.ime,' ',rv.prezime) as ime_i_prezime, count(distinct vo.putni_nalog_id) as br_putnih_naloga
	from registar_vozaca rv
	left join vozno_osoblje vo on rv.sifra_vozaca = vo.vozno_osoblje_id
	join putni_nalog pn on pn.sifra_naloga  = vo.putni_nalog_id and pn.datum between datum1 and datum2 group by rv.sifra_vozaca;
end;


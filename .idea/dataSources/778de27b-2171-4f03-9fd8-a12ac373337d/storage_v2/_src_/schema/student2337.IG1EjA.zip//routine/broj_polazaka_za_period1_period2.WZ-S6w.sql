create
    definer = student2337@`%` procedure broj_polazaka_za_period1_period2(IN datum_od_1 date, IN datum_do_1 date,
                                                                         IN datum_od_2 date, IN datum_do_2 date)
begin
    select sl.sifra_linije, sl.naziv_linije, count(distinct case when rpn1.id is not null then rpn1.id end) as broj_polazaka_period_1,
    count(distinct case when rpn2.id is not null then rpn2.id end) as broj_polazaka_period_2
    from sifarnik_linija sl
    left join relacije_putni_nalog rpn1 on rpn1.linija_id = sl.sifra_linije and rpn1.datum between datum_od_1 and datum_do_1
    left join relacije_putni_nalog rpn2 on rpn2.linija_id = sl.sifra_linije and rpn2.datum between datum_od_2 and datum_do_2
    group by sl.sifra_linije, sl.naziv_linije;
end;


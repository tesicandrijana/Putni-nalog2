create
    definer = student2337@`%` procedure broj_putnih_naloga_za_liniju(IN datum1 date, IN datum2 date, IN linija_id varchar(30))
begin
	SELECT sl.sifra_linije ,
	IFNULL(COUNT(DISTINCT putni_nalog_id), 0) as BrojLinija 
	from sifarnik_linija sl
	left join relacije_putni_nalog rpn on sl.sifra_linije = rpn.linija_id AND rpn.datum BETWEEN datum1 AND datum2
	where sl.sifra_linije = linija_id 
	GROUP by sl.sifra_linije;
end;


create
    definer = student2337@`%` procedure lista_vozaca(IN datum1 date, IN datum2 date, IN sifra_org_jedinice varchar(15))
begin
	SELECT
    rv.ime AS ImeVozača,
    rv.prezime AS PrezimeVozača,
    pn.sifra_naloga AS ŠifraPutnogNaloga,
    GROUP_CONCAT(DISTINCT rpn.linija_id) AS ŠifraLinije
FROM
    registar_vozaca rv
JOIN vozno_osoblje vo ON vo.vozno_osoblje_id = rv.sifra_vozaca
JOIN putni_nalog pn ON vo.putni_nalog_id = pn.sifra_naloga
left JOIN relacije_putni_nalog rpn ON vo.putni_nalog_id = rpn.putni_nalog_id
WHERE
    rpn.datum BETWEEN datum1 AND datum2
    AND pn.org_jedinica = org_jedinica 
GROUP BY
    ImeVozača, PrezimeVozača, ŠifraPutnogNaloga;
end;


create
    definer = student2337@`%` procedure lista_putnih_naloga(IN datum1 date, IN datum2 date, IN sifra_org_jedinice varchar(15))
begin
	select 
	pn.sifra_naloga, 
	zpn.planirani_br_predjenih_km,
	zpn.ukupan_br_predjenih_km,
	(zpn.planirani_br_predjenih_km - zpn.ukupan_br_predjenih_km) as razlika
	from putni_nalog pn 
	join zakljucak_putnog_naloga zpn on pn.sifra_naloga = zpn.putni_nalog
	where pn.datum BETWEEN datum1 AND datum2 
	and pn.org_jedinica = sifra_org_jedinice;
end;


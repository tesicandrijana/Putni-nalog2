create definer = student2337@`%` view finansije as
select `student2337`.`radnik`.`sifra_o`    AS `sifra_o`,
       `student2337`.`radnik`.`rad_mj`     AS `rad_mj`,
       sum(`student2337`.`radnik`.`plata`) AS `sum(plata)`,
       avg(`student2337`.`radnik`.`plata`) AS `avg(plata)`
from `student2337`.`radnik`
group by `student2337`.`radnik`.`sifra_o`, `student2337`.`radnik`.`rad_mj`;


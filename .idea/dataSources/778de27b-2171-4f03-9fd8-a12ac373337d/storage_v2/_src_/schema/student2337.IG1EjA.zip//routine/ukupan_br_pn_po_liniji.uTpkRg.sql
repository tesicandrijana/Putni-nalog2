create
    definer = student2337@`%` procedure ukupan_br_pn_po_liniji(IN datum1 date, IN datum2 date)
begin
	SELECT sl.sifra_linije, count(ifnull(rpn.putni_nalog_id,0)) as br_putnih_naloga
	from sifarnik_linija sl 
	left join relacije_putni_nalog rpn on rpn.linija_id = sl.sifra_linije and rpn.datum between datum1 and datum2 group by sl.sifra_linije;
end;


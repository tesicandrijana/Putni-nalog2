create
    definer = student2337@`%` procedure broj_obavljenih_voznji_po_vozilima(IN datum_od date, IN datum_do date, IN sort_order int)
BEGIN
    DECLARE sqltext VARCHAR(1000);
    SET sqltext = 'SELECT rv.garazni_broj, rv.marka_vozila, rv.registarski_br, COUNT(DISTINCT pn.sifra_naloga) AS broj_obavljenih_voznji
    FROM registar_vozila rv
    LEFT JOIN putni_nalog pn ON pn.vozilo_garazni_br = rv.garazni_broj AND pn.datum BETWEEN ? AND ? 
	group by rv.garazni_broj, rv.marka_vozila, rv.registarski_br
    ORDER BY ';

    IF sort_order = 1 THEN
        SET sqltext = CONCAT(sqltext, 'rv.garazni_broj');
    ELSEIF sort_order = 2 THEN
        SET sqltext = CONCAT(sqltext, 'rv.marka_vozila');
    ELSEIF sort_order = 3 THEN
        SET sqltext = CONCAT(sqltext, 'rv.registarski_br');
    END IF;

    SET @s = sqltext;
    set @datum1 = datum_od;
    set @datum2 = datum_do;
    PREPARE rep_stmt FROM @s;
    EXECUTE rep_stmt USING @datum1, @datum2;
    DEALLOCATE PREPARE rep_stmt;
END;


create definer = student2337@`%` view evidencijaOIgracima as
select `student2337`.`ugovor`.`datum1`                      AS `datum`,
       concat(`i`.`ime`, ' ', `i`.`prezime`, ' ', `i`.`id`) AS `igrac`,
       `student2337`.`ugovor`.`id_tima`                     AS `tim`
from (`student2337`.`igrac` `i` join `student2337`.`ugovor` on ((`i`.`id` = `student2337`.`ugovor`.`id_igraca`)));


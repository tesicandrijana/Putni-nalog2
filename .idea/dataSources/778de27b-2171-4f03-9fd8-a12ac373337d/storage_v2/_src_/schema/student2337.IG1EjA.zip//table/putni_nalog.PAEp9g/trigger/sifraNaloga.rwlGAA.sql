create definer = student2337@`%` trigger sifraNaloga
    before insert
    on putni_nalog
    for each row
begin
    set new.broj = ifnull((select max(broj)+1 from putni_nalog where godina = new.godina), 1);
    set new.sifra_naloga = CONCAT(new.broj, '/', new.godina);
end;


create
    definer = student2337@`%` procedure vozila_koje_je_vozio(IN datum1 date, IN datum2 date, IN sifra_vozaca int)
begin
	select distinct rv.ime as Ime,
	rv.prezime as Prezime,
	rvv.tip_vozila as TipVozila, rvv.marka_vozila as MarkaVozila, rvv.registarski_br as RegistarskiBroj,tv.tip_vozila
	from registar_vozaca rv
	left join vozno_osoblje vo on vo.vozno_osoblje_id = rv.sifra_vozaca
	left join putni_nalog pn on vo.putni_nalog_id = pn.sifra_naloga
	left join registar_vozila rvv on pn.vozilo_garazni_br = rvv.garazni_broj
	left join tip_vozila tv on rvv.tip_vozila=tv.tip_vozila
	where pn.datum between datum1 and datum2
	and sifra_vozaca = rv.sifra_vozaca;
end;


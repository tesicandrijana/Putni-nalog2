create
    definer = student2337@`%` procedure lista_putnih_naloga_gorivo_km_potrosnja(IN start_date date, IN end_date date, IN org_jedinica varchar(50))
begin
    select pn.sifra_naloga as putni_nalog,
	sum(ug.količina_natočeno) as ukupno_gorivo,
	zpn.ukupan_br_predjenih_km as ukupno_km,
	avg(ug.količina_natočeno / zpn.ukupan_br_predjenih_km) as prosjecna_potrosnja
    from putni_nalog pn
    join zakljucak_putnog_naloga zpn on pn.sifra_naloga = zpn.putni_nalog
    left join utrosak_goriva ug on pn.sifra_naloga = ug.putni_nalog
    where pn.datum between start_date and end_date
    and pn.org_jedinica = org_jedinica
    group by pn.sifra_naloga, zpn.ukupan_br_predjenih_km;
end;


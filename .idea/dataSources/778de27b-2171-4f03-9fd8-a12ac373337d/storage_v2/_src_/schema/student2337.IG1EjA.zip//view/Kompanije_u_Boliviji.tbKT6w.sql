create definer = student2337@`%` view Kompanije_u_Boliviji as
select `student2337`.`customers`.`Company` AS `Company`
from `student2337`.`customers`
where (`student2337`.`customers`.`Country` = 'Bolivia');


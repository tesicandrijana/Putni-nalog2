create
    definer = student2337@`%` procedure vozaci_po_linijama(IN datum1 date, IN datum2 date)
begin
    select rv.sifra_vozaca, rv.ime, rv.prezime, count(distinct rpn.linija_id) as broj_linija
    from registar_vozaca rv
    left join vozno_osoblje vo on rv.sifra_vozaca = vo.vozno_osoblje_id
    left join relacije_putni_nalog rpn on vo.putni_nalog_id = rpn.putni_nalog_id and rpn.datum between datum1 and datum2
    group by rv.sifra_vozaca, rv.ime, rv.prezime;
end;


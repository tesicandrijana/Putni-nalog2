create definer = student2337@`%` view prodaja as
select `a`.`tip`                                 AS `tip`,
       `p`.`kolicina`                            AS `kolicina`,
       (`p`.`kolicina` * `a`.`jedinicna_cijena`) AS `p.kolicina*a.jedinicna_cijena`,
       `student2337`.`odjeljenje_t`.`ime`        AS `ukupna_cijena`
from `student2337`.`artikal` `a`
         join (`student2337`.`prodan_na` `p` join `student2337`.`odjeljenje_t`
               on ((`student2337`.`odjeljenje_t`.`ime` = `p`.`odjeljenje`)))
group by `p`.`odjeljenje`;


create definer = student2337@`%` view info_plate as
select `student2337`.`radnik`.`ID`             AS `ID`,
       `student2337`.`radnik`.`sifra_o`        AS `sifra_o`,
       `student2337`.`radnik`.`plata`          AS `plata`,
       (0.10 * `student2337`.`radnik`.`plata`) AS `premija`
from `student2337`.`radnik`;


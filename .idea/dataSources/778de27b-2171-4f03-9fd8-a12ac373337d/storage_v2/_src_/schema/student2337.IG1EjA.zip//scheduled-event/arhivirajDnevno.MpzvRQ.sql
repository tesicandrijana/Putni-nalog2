create definer = student2337@`%` event arhivirajDnevno on schedule
    every '1' DAY
        starts '2023-01-19 23:59:00'
    enable
    do
    begin
	insert into pomocna select * from test;
end;


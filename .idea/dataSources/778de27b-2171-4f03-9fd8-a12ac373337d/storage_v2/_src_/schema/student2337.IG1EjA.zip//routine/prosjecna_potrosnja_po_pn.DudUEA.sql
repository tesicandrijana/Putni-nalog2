create
    definer = student2337@`%` procedure prosjecna_potrosnja_po_pn(IN datum_od date, IN datum_do date)
BEGIN
SELECT 
    ug.putni_nalog, pn.datum,
    AVG(ug.količina_natočeno / zpn.ukupan_br_predjenih_km) AS prosjecna_potrosnja
FROM 
    utrosak_goriva ug 
JOIN 
    zakljucak_putnog_naloga zpn ON ug.putni_nalog = zpn.putni_nalog
join putni_nalog pn on pn.sifra_naloga = zpn.putni_nalog and pn.datum BETWEEN datum_od AND datum_do
GROUP BY 
    ug.putni_nalog;

END;


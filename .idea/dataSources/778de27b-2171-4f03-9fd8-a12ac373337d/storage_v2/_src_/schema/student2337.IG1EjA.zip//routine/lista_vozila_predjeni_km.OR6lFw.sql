create
    definer = student2337@`%` procedure lista_vozila_predjeni_km(IN datum1 date, IN datum2 date)
begin
    select
        rvv.garazni_broj as garazni_broj,
        rvv.marka_vozila as marka_vozila,
        rvv.tip_vozila as tip_vozila,
        coalesce(sum(zpn.ukupan_br_predjenih_km), 0) as ukupni_kilometri
    from registar_vozila rvv
    left join putni_nalog pn on rvv.garazni_broj = pn.vozilo_garazni_br
    left join zakljucak_putnog_naloga zpn on pn.sifra_naloga = zpn.putni_nalog
    where pn.datum between datum1 and datum2
    group by rvv.garazni_broj, rvv.marka_vozila, rvv.tip_vozila;
end;


create
    definer = student2337@`%` procedure lista_vozaca_nisu_vozili(IN datum1 date, IN datum2 date)
begin
 select rv.sifra_vozaca, rv.ime, rv.prezime
    from registar_vozaca rv
    left outer join (
        select distinct vo.vozno_osoblje_id
        from vozno_osoblje vo
        join putni_nalog pn on pn.sifra_naloga = vo.putni_nalog_id and pn.datum between datum1 and datum2
    ) as subquery on rv.sifra_vozaca = subquery.vozno_osoblje_id
    where subquery.vozno_osoblje_id is null;

end;

